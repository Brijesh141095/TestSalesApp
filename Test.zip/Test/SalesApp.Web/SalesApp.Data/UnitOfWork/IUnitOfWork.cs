﻿using SalesApp.Data.Models;
using SalesApp.Data.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace SalesApp.Data.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IGenericRepository<BrandMaster> BrandRepository { get; }
        IGenericRepository<ModelMaster> ModelRepository { get; }
        IGenericRepository<DeviceImport> DeviceImportRepository { get; }
        IGenericRepository<DeviceSell> DeviceSellRepository { get; }

        void Save();
    }
}
