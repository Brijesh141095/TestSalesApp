﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;
using SalesApp.Data.Models;
using SalesApp.Data.Repository;

namespace SalesApp.Data.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DbContext _context;
        private DbTransaction _transaction;
        private IGenericRepository<BrandMaster> brandRepository;
        private IGenericRepository<ModelMaster> modelRepository;
        private IGenericRepository<DeviceImport> deviceImportRepository;
        private IGenericRepository<DeviceSell> deviceSellRepository;

        public UnitOfWork()
        {
            this._context = new SalesDBContext();
        }
        public IGenericRepository<BrandMaster> BrandRepository => brandRepository ?? (this.brandRepository = new GenericRepository<BrandMaster>(_context));
        public IGenericRepository<ModelMaster> ModelRepository => modelRepository ?? (this.modelRepository = new GenericRepository<ModelMaster>(_context));
        public IGenericRepository<DeviceImport> DeviceImportRepository => deviceImportRepository ?? (this.deviceImportRepository = new GenericRepository<DeviceImport>(_context));
        public IGenericRepository<DeviceSell> DeviceSellRepository => deviceSellRepository ?? (this.deviceSellRepository = new GenericRepository<DeviceSell>(_context));

        public void Save()
        {
            try
            {
                _context.SaveChanges();
            }
            catch (Exception exception)
            {
                //Log Exception
                //throw;
                Console.WriteLine(exception);
            }
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed && disposing)
            {
                _context.Dispose();
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
