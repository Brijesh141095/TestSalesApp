﻿using System;
using System.Collections.Generic;

namespace SalesApp.Data.Models
{
    public partial class BrandMaster
    {
        public BrandMaster()
        {
            ModelMaster = new HashSet<ModelMaster>();
        }

        public int BrandId { get; set; }
        public string BrandName { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }

        public ICollection<ModelMaster> ModelMaster { get; set; }
    }
}
