﻿using System;
using System.Collections.Generic;

namespace SalesApp.Data.Models
{
    public partial class ModelMaster
    {
        public ModelMaster()
        {
            DeviceImport = new HashSet<DeviceImport>();
        }

        public int ModelId { get; set; }
        public string ModelName { get; set; }
        public int? BrandId { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }

        public BrandMaster Brand { get; set; }
        public ICollection<DeviceImport> DeviceImport { get; set; }
    }
}
