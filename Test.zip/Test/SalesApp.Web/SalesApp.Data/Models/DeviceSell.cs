﻿using System;
using System.Collections.Generic;

namespace SalesApp.Data.Models
{
    public partial class DeviceSell
    {
        public int SellId { get; set; }
        public int? DeviceId { get; set; }
        public string BuyerName { get; set; }
        public string BuyerNumber { get; set; }
        public DateTime? SellingDate { get; set; }
        public int? SellingPrize { get; set; }
        public string Discount { get; set; }
        public string DiscountedPrize { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }

        public DeviceImport Device { get; set; }
    }
}
