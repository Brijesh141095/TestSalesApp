﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SalesApp.Data.Models
{
    public partial class SalesDBContext : DbContext
    {
        public SalesDBContext()
        {
        }

        public SalesDBContext(DbContextOptions<SalesDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BrandMaster> BrandMaster { get; set; }
        public virtual DbSet<DeviceImport> DeviceImport { get; set; }
        public virtual DbSet<DeviceSell> DeviceSell { get; set; }
        public virtual DbSet<ModelMaster> ModelMaster { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=SRKSUR5107LT\\SQLEXPRESS;Database=SalesDb;User ID=sa;Password=srkay@1234");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BrandMaster>(entity =>
            {
                entity.HasKey(e => e.BrandId);

                entity.Property(e => e.BrandName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<DeviceImport>(entity =>
            {
                entity.HasKey(e => e.DeviceId);

                entity.Property(e => e.CreatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Imei).HasColumnName("IMEI");

                entity.Property(e => e.PurchaseDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.HasOne(d => d.Model)
                    .WithMany(p => p.DeviceImport)
                    .HasForeignKey(d => d.ModelId)
                    .HasConstraintName("FK_DeviceImport_ModelMaster");
            });

            modelBuilder.Entity<DeviceSell>(entity =>
            {
                entity.HasKey(e => e.SellId);

                entity.Property(e => e.BuyerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BuyerNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.Discount)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DiscountedPrize)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SellingDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.HasOne(d => d.Device)
                    .WithMany(p => p.DeviceSell)
                    .HasForeignKey(d => d.DeviceId)
                    .HasConstraintName("FK_DeviceSell_DeviceSell");
            });

            modelBuilder.Entity<ModelMaster>(entity =>
            {
                entity.HasKey(e => e.ModelId);

                entity.Property(e => e.CreatedDateTime).HasColumnType("datetime");

                entity.Property(e => e.ModelName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDateTime).HasColumnType("datetime");

                entity.HasOne(d => d.Brand)
                    .WithMany(p => p.ModelMaster)
                    .HasForeignKey(d => d.BrandId)
                    .HasConstraintName("FK_ModelMaster_BrandMaster");
            });
        }
    }
}
