﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SalesApp.Entities.Models
{
    public class ModelMaster
    {
        public int ModelId { get; set; }
        public string ModelName { get; set; }
        public int? BrandId { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
    }
}
