﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SalesApp.Entities.Models
{
    public class DeviceImport
    {
        public int DeviceId { get; set; }
        public long? Imei { get; set; }
        public int? ModelId { get; set; }
        public DateTime? PurchaseDate { get; set; }
        public int? PurchasePrize { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
    }
}
