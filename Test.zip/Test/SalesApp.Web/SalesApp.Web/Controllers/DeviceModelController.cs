﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SalesApp.Services.DeviceModel;
using SalesApp.Web.Common;

namespace SalesApp.Web.Controllers
{
    [Produces("application/json")]
    [Route("api/Brand")]
    public class DeviceModelController : Controller
    {

        private readonly IDeviceModelService _deviceModelService;

        public DeviceModelController(IDeviceModelService deviceModelService) {
            this._deviceModelService = deviceModelService;
        }

        [HttpGet]
        [Route("")]
        [Route("brandModels")]
        public IActionResult GetModels()
        {
            try
            {
                var brandModels = _deviceModelService.GetModels();
                if (brandModels != null && brandModels.Count() > 0)
                {
                    return Ok(new Responce { message = "Data found successfully", code = "OK_200", data = brandModels, errorstatus = false });
                }
                return NotFound(new Responce { message = "No data found", code = "NOTFOUND_200", errorstatus = false });
                // return Json(_brandService.GetBrands());
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }

        [HttpPost]
        [Route("addBrandModel")]
        public IActionResult AddBrandModel([FromBody] Entities.Models.ModelMaster brandModel)
        {

            //return Json(_brandService.AddBrand(brand));
            try
            {
                if (ModelState.IsValid)
                {
                    var addedBrandModel = _deviceModelService.AddModel(brandModel);
                    if (addedBrandModel > 0)
                    {
                        return Ok(new Responce { message = "Data added successfully", code = "OK_200", data = addedBrandModel, errorstatus = false });
                    }
                    else if (addedBrandModel == -99)
                    {
                        return Ok(new Responce { message = "Data Already exist", code = "EXIST_200", errorstatus = false });
                    }
                    return Ok(new Responce { message = "something went wrong.", code = "ERROR_400", errorstatus = true });
                }
                return BadRequest(new Responce { message = "Bad Input", code = "ERROR_400", errorstatus = true });
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }

        [HttpPatch]
        [Route("updateBrandModel")]
        public IActionResult UpdateBrandModel([FromBody] Entities.Models.ModelMaster brandModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var updatedBrandModel = _deviceModelService.UpdateModel(brandModel);
                    if (updatedBrandModel > 0)
                    {
                        return Ok(new Responce { message = "Data updated successfully", code = "OK_200", data = updatedBrandModel, errorstatus = false });
                    }
                    return Ok(new Responce { message = "something went wrong.", code = "ERROR_400", errorstatus = true });
                }
                return BadRequest(new Responce { message = "Bad Input", code = "ERROR_400", errorstatus = true });
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }

        [HttpDelete]
        [Route("deleteBrandModel/{brandModelId}")]
        public IActionResult DeleteBrandModel(int brandModelId)
        {
            try
            {
                if (brandModelId > 0)
                {
                    var deletedBrandModel = _deviceModelService.DeleteModel(brandModelId);
                    if (deletedBrandModel > 0)
                    {
                        return Ok(new Responce { message = "Data Deleted successfully", code = "OK_200", data = deletedBrandModel, errorstatus = false });
                    }
                    return Ok(new Responce { message = "something went wrong.", code = "ERROR_400", errorstatus = true });
                }
                return BadRequest(new Responce { message = "Bad Input", code = "ERROR_400", errorstatus = true });
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }


    }
}