﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SalesApp.Services.Device;
using SalesApp.Web.Common;

namespace SalesApp.Web.Controllers
{
    [Produces("application/json")]
    [Route("api/Device")]
    public class DeviceController : Controller
    {
        private readonly IDeviceService _deviceService;

        public DeviceController(IDeviceService deviceService) {
            this._deviceService = deviceService;
        }

        [HttpPost]
        [Route("importDevice")]
        public ActionResult ImportDevice([FromBody] Entities.Models.DeviceImport device) {
            try
            {
                if (ModelState.IsValid)
                {
                    var addedDevice = _deviceService.ImportDevice(device);
                    if (addedDevice > 0)
                    {
                        return Ok(new Responce { message = "Data added successfully", code = "OK_200", data = addedDevice, errorstatus = false });
                    }
                    else if (addedDevice == -99)
                    {
                        return Ok(new Responce { message = "Data Already exist", code = "EXIST_200", errorstatus = false });
                    }
                    return Ok(new Responce { message = "something went wrong.", code = "ERROR_400", errorstatus = true });
                }
                return BadRequest(new Responce { message = "Bad Input", code = "ERROR_400", errorstatus = true });
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }

        [HttpPost]
        [Route("sellDevice")]
        public ActionResult SellDevice([FromBody] Entities.Models.DeviceSell device)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var soldDevice = _deviceService.SellDevice(device);
                    if (soldDevice > 0)
                    {
                        return Ok(new Responce { message = "Data added successfully", code = "OK_200", data = soldDevice, errorstatus = false });
                    }
                    else if (soldDevice == -99)
                    {
                        return Ok(new Responce { message = "Data Already exist", code = "EXIST_200", errorstatus = false });
                    }
                    return Ok(new Responce { message = "something went wrong.", code = "ERROR_400", errorstatus = true });
                }
                return BadRequest(new Responce { message = "Bad Input", code = "ERROR_400", errorstatus = true });
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }
    }
}