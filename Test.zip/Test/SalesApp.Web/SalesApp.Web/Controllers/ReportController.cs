﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using SalesApp.Services.Report;
using SalesApp.Web.Common;

namespace SalesApp.Web.Controllers
{
    [Produces("application/json")]
    [Route("api/Report")]
    public class ReportController : Controller
    {
        private readonly IReportService _reportService;

        [ActivatorUtilitiesConstructor]
        public ReportController(IReportService reportService)
        {
            this._reportService = reportService;
        }

        
        public ReportController()
        {
        }

        [HttpGet]
        [Route("monthlySell/{fromDate}/{toDate}")]
        public IActionResult MonthlySell(string fromDate, string toDate)
        {
            try
            {
                var sellReport = _reportService.GetMonthlySell(fromDate, toDate);
                if (sellReport != null)
                {
                    return Ok(new Responce { message = "Data found successfully", code = "OK_200", data = sellReport, errorstatus = false });
                }
                return NotFound(new Responce { message = "No data found", code = "NOTFOUND_200", errorstatus = false });
                // return Json(_brandService.GetBrands());
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }

        [HttpGet]
        [Route("monthlyBrandwiseSell/{fromDate}/{toDate}")]
        public IActionResult MonthlyBrandwiseSell(string fromDate, string toDate)
        {
            try
            {
                var sellReport = _reportService.GetMonthlyBrandwiseSell(fromDate, toDate);
                if (sellReport != null)
                {
                    return Ok(new Responce { message = "Data found successfully", code = "OK_200", data = sellReport, errorstatus = false });
                }
                return NotFound(new Responce { message = "No data found", code = "NOTFOUND_200", errorstatus = false });
                // return Json(_brandService.GetBrands());
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }

        [HttpGet]
        [Route("MonthlyBrandwiseSellWithProfitLoss/{fromDate}/{toDate}")]
        public IActionResult MonthlyBrandwiseSellWithProfitLoss(string fromDate, string toDate)
        {
            try
            {
                var sellReport = _reportService.GetMonthlyBrandwiseSellWithProfitLoss(fromDate, toDate);
                if (sellReport != null)
                {
                    return Ok(new Responce { message = "Data found successfully", code = "OK_200", data = sellReport, errorstatus = false });
                }
                return NotFound(new Responce { message = "No data found", code = "NOTFOUND_200", errorstatus = false });
                // return Json(_brandService.GetBrands());
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }
    }
}