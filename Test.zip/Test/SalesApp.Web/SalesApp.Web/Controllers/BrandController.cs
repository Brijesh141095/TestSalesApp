﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SalesApp.Services.Brand;
using SalesApp.Web.Common;

namespace SalesApp.Web.Controllers
{
   [Produces("application/json")]
   [Route("api/Brand")]
    public class BrandController : Controller
    {
        private readonly IBrandService _brandService;

        public BrandController(IBrandService brandService) {
            this._brandService = brandService;
        }
        
        [HttpGet]
        [Route("")]
        [Route("brands")]
        public IActionResult GetBrands(){
            
            try
            {
                var brands = _brandService.GetBrands();
                if (brands != null && brands.Count() > 0) {
                    return Ok(new Responce { message= "Data found successfully",code = "OK_200",data=brands, errorstatus = false});
                }
                return NotFound(new Responce { message = "No data found", code = "NOTFOUND_200", errorstatus = false });
               // return Json(_brandService.GetBrands());
            }
            catch (Exception e) {
                return BadRequest(new Responce { message = "Exception",code = "ERROR_400", errorstatus = true,data = e.Message });
            }
        }

        [HttpPost] 
        [Route("addBrand")]
        public IActionResult AddBrand([FromBody] Entities.Models.BrandMaster brand)
        {
            
                //return Json(_brandService.AddBrand(brand));
                try
                {
                    if (ModelState.IsValid) {
                        var addedBrand = _brandService.AddBrand(brand);
                        if (addedBrand > 0)
                        {
                            return Ok(new Responce { message = "Data added successfully", code = "OK_200", data = addedBrand, errorstatus = false });
                        }
                        else if (addedBrand == -99) {
                            return Ok(new Responce { message = "Data Already exist", code = "EXIST_200", errorstatus = false });
                        }
                        return Ok(new Responce { message = "something went wrong.", code = "ERROR_400", errorstatus = true});
                    }
                    return BadRequest(new Responce { message = "Bad Input", code = "ERROR_400", errorstatus = true});
                }
                catch (Exception e) {
                    return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
                }   
        }

        [HttpPatch]
        [Route("updateBrand")]
        public IActionResult UpdateBrand([FromBody] Entities.Models.BrandMaster brand)
        {

            //return Json(_brandService.AddBrand(brand));
            try
            {
                if (ModelState.IsValid)
                {
                    var updatedBrand = _brandService.UpdateBrand(brand);
                    if (updatedBrand > 0)
                    {
                        return Ok(new Responce { message = "Data updated successfully", code = "OK_200", data = updatedBrand, errorstatus = false });
                    }
                    return Ok(new Responce { message = "something went wrong.", code = "ERROR_400", errorstatus = true });
                }
                return BadRequest(new Responce { message = "Bad Input", code = "ERROR_400", errorstatus = true });
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }

        [HttpDelete]
        [Route("deleteBrand/{brandId}")]
        public IActionResult DeleteBrand(int brandId) {
            try {
                if (brandId > 0) {
                    var deletedBrand = _brandService.DeleteBrand(brandId);
                    if (deletedBrand > 0) {
                        return Ok(new Responce { message = "Data Deleted successfully", code = "OK_200", data = deletedBrand, errorstatus = false });
                    }
                    return Ok(new Responce { message = "something went wrong.", code = "ERROR_400", errorstatus = true });
                }
                return BadRequest(new Responce { message = "Bad Input", code = "ERROR_400", errorstatus = true });
            }
            catch (Exception e)
            {
                return BadRequest(new Responce { message = "Exception", code = "ERROR_400", errorstatus = true, data = e.Message });
            }
        }
    }
}