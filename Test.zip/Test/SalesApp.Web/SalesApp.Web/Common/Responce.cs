﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesApp.Web.Common
{
    public class Responce
    {
        public object data { get; set; }
        public string message { get; set; }
        public string code { get; set; }
        public bool errorstatus { get; set; }

    }
}
