﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SalesApp.Web.Controllers;
using System;
using System.Collections.Generic;
using System.Text;


namespace SalesApp.Tests.ControllerTest
{
    [TestClass]
    public class ReportControllerTest
    {
        ReportController reportController = new ReportController();

        [TestMethod]
        public void GetMonthlyReportTest() {
            var fromDate = "2018-01-15";
            var toDate = "2019-10-20";
            ViewResult result = reportController.MonthlySell(fromDate,toDate) as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetMonthlyBrandReportTest()
        {
            var fromDate = "2018-01-15";
            var toDate = "2019-10-20";
            ViewResult result = reportController.MonthlyBrandwiseSell(fromDate, toDate) as ViewResult;
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void GetProfitLossReportTest()
        {
            var fromDate = "2018-01-15";
            var toDate = "2019-10-20";
            ViewResult result = reportController.MonthlyBrandwiseSellWithProfitLoss(fromDate, toDate) as ViewResult;
            Assert.IsNotNull(result);
        }
    }
}
