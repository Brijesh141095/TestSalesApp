﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SalesApp.Services.Report
{
    public interface IReportService
    {
        object GetMonthlySell(string fromDate, string toDate);
        object GetMonthlyBrandwiseSell(string fromDate, string toDate);
        object GetMonthlyBrandwiseSellWithProfitLoss(string fromDate, string toDate);
    }
}
