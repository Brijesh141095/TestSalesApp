﻿using SalesApp.Data.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace SalesApp.Services.Report
{
    public class ReportService : IReportService
    {
        private readonly IUnitOfWork unitOfWork;
        public ReportService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public object GetMonthlySell(string fromDateParam, string toDateParam)
        {
            var fromDate = Convert.ToDateTime(fromDateParam);
            var toDate = Convert.ToDateTime(toDateParam);
            fromDate = new DateTime(2019, 4, 1);
            toDate = DateTime.Now;
            var deviceSellData = unitOfWork.DeviceSellRepository.GetAll().ToList();

            var sellingData = from s in deviceSellData
                              where s.SellingDate > fromDate && s.SellingDate < toDate
                              group s by (s.SellingDate.Value.Month.ToString() + "-" + s.SellingDate.Value.Year.ToString()) into grp 
                              select new {
                                  MonthYear = grp.Key,
                                  SellingAmount = grp.Sum(x => x.SellingPrize),  
                                  UnitCount = grp.Count(x=>1==1)
                              };

            return sellingData;
        }

        public object GetMonthlyBrandwiseSell(string fromDateParam, string toDateParam)
        {

            var fromDate = Convert.ToDateTime(fromDateParam);
            var toDate = Convert.ToDateTime(toDateParam);
            var deviceSellData = unitOfWork.DeviceSellRepository.GetAll().ToList();
            var deviceImportData = unitOfWork.DeviceImportRepository.GetAll().ToList();
            var deviceModelData = unitOfWork.ModelRepository.GetAll().ToList();
            var deviceBrandData = unitOfWork.BrandRepository.GetAll().ToList();

            var sellingData = from s in deviceSellData
                              join d in deviceImportData on s.DeviceId equals d.DeviceId
                              join m in deviceModelData on d.ModelId equals m.ModelId
                              join b in deviceBrandData on m.BrandId equals b.BrandId
                              where s.SellingDate > fromDate && s.SellingDate < toDate
                              group s by (s.SellingDate.Value.Month.ToString() + "-" + s.SellingDate.Value.Year.ToString(),b.BrandName ) into grp
                              select new
                              {
                                  MonthYear = grp.Key,
                                  SellingAmount = grp.Sum(x => x.SellingPrize),
                                  UnitCount = grp.Count(x => 1 == 1),
                                  
                              };

            return sellingData;
        }

        public object GetMonthlyBrandwiseSellWithProfitLoss(string fromDateParam, string toDateParam)
        {
            var fromDate = Convert.ToDateTime(fromDateParam);
            var toDate = Convert.ToDateTime(toDateParam);
            var deviceSellData = unitOfWork.DeviceSellRepository.GetAll().ToList();
            var deviceImportData = unitOfWork.DeviceImportRepository.GetAll().ToList();
            var deviceModelData = unitOfWork.ModelRepository.GetAll().ToList();
            var deviceBrandData = unitOfWork.BrandRepository.GetAll().ToList();

            var sellingData = from s in deviceSellData
                              join d in deviceImportData on s.DeviceId equals d.DeviceId
                              join m in deviceModelData on d.ModelId equals m.ModelId
                              join b in deviceBrandData on m.BrandId equals b.BrandId
                              where s.SellingDate > fromDate && s.SellingDate < toDate
                              group s by (s.SellingDate.Value.Month.ToString() + "-" + s.SellingDate.Value.Year.ToString(), b.BrandName) into grp
                              //join dd in deviceImportData on grp.FirstOrDefault().DeviceId equals dd.DeviceId
                              select new
                              {
                                  MonthYear = grp.Key,
                                  SellingAmount = grp.Sum(x => x.SellingPrize),
                                  UnitCount = grp.Count(x => 1 == 1),
                                  profitLoss  = grp.Sum(x=>Convert.ToInt16(x.DiscountedPrize))
                              };

            return sellingData;
        }
    }
}
