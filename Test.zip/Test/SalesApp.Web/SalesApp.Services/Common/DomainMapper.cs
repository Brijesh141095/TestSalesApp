﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace SalesApp.Services.Common
{
    public static class DomainMapper
    {
        public static void CreateMap()
        {
            Mapper.Initialize(cfg =>
            {

                cfg.CreateMap<SalesApp.Data.Models.BrandMaster, SalesApp.Entities.Models.BrandMaster>();
                cfg.CreateMap<SalesApp.Entities.Models.BrandMaster, SalesApp.Data.Models.BrandMaster>()
                .ForMember(src => src.ModelMaster,opt=>opt.Ignore());

                cfg.CreateMap<SalesApp.Data.Models.ModelMaster, SalesApp.Entities.Models.ModelMaster>();
                cfg.CreateMap<SalesApp.Entities.Models.ModelMaster, SalesApp.Data.Models.ModelMaster>()
                .ForMember(src => src.DeviceImport, opt => opt.Ignore())
                .ForMember(src => src.Brand, opt => opt.Ignore());

                cfg.CreateMap<SalesApp.Data.Models.DeviceImport, SalesApp.Entities.Models.DeviceImport>();
                cfg.CreateMap<SalesApp.Entities.Models.DeviceImport, SalesApp.Data.Models.DeviceImport>()
                .ForMember(src => src.Model, opt => opt.Ignore())
                .ForMember(src => src.DeviceSell, opt => opt.Ignore());

                cfg.CreateMap<SalesApp.Data.Models.DeviceSell, SalesApp.Entities.Models.DeviceSell>();
                cfg.CreateMap<SalesApp.Entities.Models.DeviceSell, SalesApp.Data.Models.DeviceSell>()
                .ForMember(src => src.Device, opt => opt.Ignore());
                /* etc */
            });
            //Mapper.Initialize(cfg =>
            //{
            //    //cfg.CreateMap<SupervisorEmployee, SupervisorViewModel>()
            //    //.ForMember
            //    //    (dst => dst.Name, src => src.MapFrom<string>(e => SupervisorViewModel.MapName(e)))
            //    //.ForMember
            //    //    (dst => dst.OfficePhone, src => src.MapFrom<string>(e => e.OfficePhone.FormatPhone(e.OfficePhoneIsForeign)))
            //    //.ForMember
            //    //    (dst => dst.HomePhone, src => src.MapFrom<string>(e => e.HomePhone.FormatPhone(e.HomePhoneIsForeign)))
            //    //.ForMember
            //    //    (dst => dst.MobilePhone, src => src.MapFrom<string>(e => e.MobilePhone.FormatPhone(e.MobilePhoneIsForeign)));
            //});
        }

    }
}
