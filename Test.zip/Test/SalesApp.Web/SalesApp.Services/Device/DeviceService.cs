﻿using SalesApp.Data.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesApp.Services.Device
{
    public class DeviceService : IDeviceService
    {
        private readonly IUnitOfWork unitOfWork;
        public DeviceService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        //add device into system whenever it imported
        public int ImportDevice(Entities.Models.DeviceImport device)
        {
            var deviceModel = AutoMapper.Mapper.Map<Data.Models.DeviceImport>(device);
            var existingDevice = unitOfWork.DeviceImportRepository.FindBy(d => (d.DeviceId == device.DeviceId || d.Imei == device.Imei)).SingleOrDefault();
            if (existingDevice == null)
            {
                deviceModel.CreatedDateTime = DateTime.Now;
                var addedDevice = unitOfWork.DeviceImportRepository.Add(deviceModel);
                unitOfWork.DeviceImportRepository.Save();
                unitOfWork.Save();
                return addedDevice.DeviceId;
            }
            else
            {
                return -99; //for already sold device
            }
        }

        //add device as sold device
        public int SellDevice(Entities.Models.DeviceSell device)
        {
            var deviceModel = AutoMapper.Mapper.Map<Data.Models.DeviceSell>(device);
            deviceModel.DiscountedPrize = Convert.ToString(device.SellingPrize - unitOfWork.DeviceImportRepository.FindBy(d => d.DeviceId == device.DeviceId).SingleOrDefault().PurchasePrize);
            var soldDevice = unitOfWork.DeviceSellRepository.FindBy(d => (d.DeviceId == device.DeviceId)).SingleOrDefault();
            if (soldDevice == null)
            {
                deviceModel.CreatedDateTime = DateTime.Now;
                var addedSoldDevice = unitOfWork.DeviceSellRepository.Add(deviceModel);
                unitOfWork.DeviceSellRepository.Save();
                unitOfWork.Save();
                return addedSoldDevice.SellId;    
            }
            else
            {
                return -99; //for already sold device
            }
        }
    }
}
