﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SalesApp.Services.Device
{
    public interface IDeviceService
    {
        int ImportDevice(Entities.Models.DeviceImport device);
        int SellDevice(Entities.Models.DeviceSell device);
    }
}
