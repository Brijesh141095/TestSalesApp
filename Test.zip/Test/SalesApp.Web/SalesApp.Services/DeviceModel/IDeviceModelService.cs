﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SalesApp.Services.DeviceModel
{
    public interface IDeviceModelService
    {
        IEnumerable<Entities.Models.ModelMaster> GetModels();
        int AddModel(Entities.Models.ModelMaster brandModel);
        int UpdateModel(Entities.Models.ModelMaster brandModel);
        int DeleteModel(int brandModelId);
    }
}
