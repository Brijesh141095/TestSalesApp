﻿using SalesApp.Data.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesApp.Services.DeviceModel
{
    public class DeviceModelService : IDeviceModelService
    {
        private readonly IUnitOfWork unitOfWork;
        public DeviceModelService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }
        public IEnumerable<Entities.Models.ModelMaster> GetModels()
        {
            var brandModels = unitOfWork.ModelRepository.GetAll().AsEnumerable();
            if (brandModels != null)
            {
                return AutoMapper.Mapper.Map<IEnumerable<Entities.Models.ModelMaster>>(brandModels);
            }
            return null;
        }

        public int AddModel(Entities.Models.ModelMaster modelBrand)
        {
            var brandModel = AutoMapper.Mapper.Map<Data.Models.ModelMaster>(modelBrand);
            var existingModel = unitOfWork.ModelRepository.FindBy(m => (m.ModelName == modelBrand.ModelName && m.Brand.BrandId == modelBrand.BrandId)).SingleOrDefault();
            if (existingModel == null)
            {
                brandModel.CreatedDateTime = DateTime.Now;
                var addedModel = unitOfWork.ModelRepository.Add(brandModel);
                unitOfWork.BrandRepository.Save();
                unitOfWork.Save();
                return addedModel.ModelId;
            }
            else
            {
                return -99; //for already exist
            }
        }
        public int UpdateModel(Entities.Models.ModelMaster brandModel)
        {
            var existingModel = unitOfWork.ModelRepository.FindBy(m => m.ModelId == brandModel.ModelId).SingleOrDefault();
            if (existingModel != null)
            {
                existingModel.UpdatedDateTime = DateTime.Now;
                if (!string.IsNullOrEmpty(brandModel.ModelName))
                {
                    existingModel.ModelName = brandModel.ModelName;
                }
                if (brandModel.BrandId > 0)
                {
                    existingModel.BrandId = brandModel.BrandId;
                }
                var updatedModel = unitOfWork.ModelRepository.Edit(existingModel);
                unitOfWork.ModelRepository.Save();
                unitOfWork.Save();
                return updatedModel.ModelId;
            }
            return 0;
        }

        public int DeleteModel(int brandModelId)
        {
            var existingModel = unitOfWork.ModelRepository.FindBy(m => m.ModelId == brandModelId).SingleOrDefault();
            if (existingModel != null)
            {
                var deletedModel = unitOfWork.ModelRepository.Delete(existingModel);
                unitOfWork.ModelRepository.Save();
                unitOfWork.Save();
                return deletedModel.ModelId;
            }
            return 0;
        }
    }
}
