﻿using SalesApp.Data.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesApp.Services.Brand
{
    public class BrandService : IBrandService
    {
        private readonly IUnitOfWork unitOfWork;
        public BrandService(IUnitOfWork unitOfWork) {
            this.unitOfWork = unitOfWork;
        }
        public IEnumerable<Entities.Models.BrandMaster> GetBrands() {
            var brands = unitOfWork.BrandRepository.GetAll().AsEnumerable();
            if (brands != null) {
                return AutoMapper.Mapper.Map<IEnumerable<Entities.Models.BrandMaster>>(brands);
            }
            return null;
        }

        public int AddBrand(Entities.Models.BrandMaster brand)
        {
            var brandModel = AutoMapper.Mapper.Map<Data.Models.BrandMaster>(brand);
            var existBrand = unitOfWork.BrandRepository.FindBy(b => b.BrandName == brand.BrandName).SingleOrDefault();
            if (existBrand == null)
            {
                brandModel.CreatedDateTime = DateTime.Now;
                var addedBrand = unitOfWork.BrandRepository.Add(brandModel);
                unitOfWork.BrandRepository.Save();
                unitOfWork.Save();
                return addedBrand.BrandId;
            }
            else {
                return -99; //for already exist
            }
        }
        public int UpdateBrand(Entities.Models.BrandMaster brand)
        {
            var existingBrand = unitOfWork.BrandRepository.FindBy(b => b.BrandId == brand.BrandId).SingleOrDefault();
            if (existingBrand != null) {
                existingBrand.UpdatedDateTime = DateTime.Now;
                if (!string.IsNullOrEmpty(brand.BrandName))
                {
                    existingBrand.BrandName = brand.BrandName;
                }
                var updatedBrand = unitOfWork.BrandRepository.Edit(existingBrand);
                unitOfWork.BrandRepository.Save();
                unitOfWork.Save();
                return updatedBrand.BrandId;
            }
            return 0;
        }

        public int DeleteBrand(int BrandId) {
            var existingBrand = unitOfWork.BrandRepository.FindBy(b => b.BrandId == BrandId).SingleOrDefault();
            if (existingBrand != null) {
                var deletedBrand = unitOfWork.BrandRepository.Delete(existingBrand);
                unitOfWork.BrandRepository.Save();
                unitOfWork.Save();
                return deletedBrand.BrandId;
            }
            return 0;
        }
    }
}
