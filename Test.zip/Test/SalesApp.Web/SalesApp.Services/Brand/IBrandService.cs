﻿using System;
using System.Collections.Generic;
using System.Text;
using SalesApp.Entities.Models;


namespace SalesApp.Services.Brand
{
    public interface IBrandService
    {
        IEnumerable<Entities.Models.BrandMaster> GetBrands();
        int AddBrand(Entities.Models.BrandMaster brand);
        int UpdateBrand(Entities.Models.BrandMaster brand);
        int DeleteBrand(int BrandId);
    }
}
